document.addEventListener('DOMContentLoaded', () => {
    document.body.classList.add('wipe-animation');
});